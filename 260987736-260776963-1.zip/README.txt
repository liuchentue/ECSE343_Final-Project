README
To modify the number of Gaussian (number of result segments) modify the number of variable: “n_components” to desired number

To process the downscaled version of the picture, uncomment the function of cv2.resize() and modify the parameter taken the function. 
The position of this function is indicated by the comment in the main function. If error occur, lower the variable “iterations” by 1, 
this is because you resize the picture too much, and the EM iteration couldn’t downscale the picture again as much.